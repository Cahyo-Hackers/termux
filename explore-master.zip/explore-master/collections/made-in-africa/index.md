---
items:
 - frontlinesms/frontlinesms2
 - ushahidi/SMSSync
 - praekeltfoundation/vumi
 - rapidpro/rapidpro
 - pluspeople/pesaPi
 - praekeltfoundation/junebug
 - chisimba/chisimba
 - OpenInstitute/OpenDuka
 - CodeForAfrica/GotToVote
 - universalcore/elastic-git
 - nyaruka/smartmin
 - gernest/utron
 - ushahidi/platform
 - Yorubaname/yorubaname-website
display_name: Made in Africa
created_by: mozzadrella
---
Developers in Africa use open source technology to solve some of the world's most intractable problems and grow their business ecosystems. Here's a snapshot of local projects across the continent.
