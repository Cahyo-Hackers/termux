---
items:
 - GliaX/Stethoscope
 - HospitalRun/hospitalrun-frontend
 - get-alex/alex
 - coralproject/talk
 - hotosm/tasking-manager
 - OptiKey/OptiKey
 - ifmeorg/ifme
 - RefugeRestrooms/refugerestrooms
 - hurricane-response/florence-api
 - rubyforgood/terrastories
 - rubyforgood/diaper
 - rubyforgood/playtime
 - rubyforgood/demand-progress
 - ebimodeling/ghgvc
 - IEEEKeralaSection/rescuekerala
 - Data4Democracy/ethics-resources
 - civicdata/civicdata.github.io
 - Greenstand/Development-Overview
display_name: Social Impact
created_by: bescalante
---
Improving our world through open source technology
