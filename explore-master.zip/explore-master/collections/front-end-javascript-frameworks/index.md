---
items:
 - marko-js/marko
 - mithriljs/mithril.js
 - angular/angular
 - emberjs/ember.js
 - knockout/knockout
 - tastejs/todomvc
 - spine/spine
 - vuejs/vue
 - Polymer/polymer
 - facebook/react
 - matreshkajs/matreshka
 - aurelia/framework
 - optimizely/nuclear-js
 - jashkenas/backbone
 - dojo/dojo
 - jorgebucaran/hyperapp
 - riot/riot
 - daemonite/material
 - polymer/lit-element
 - aurelia/aurelia
 - sveltejs/svelte
display_name: Front-end JavaScript frameworks
created_by: jonrohan
---
While the number of ways to organize JavaScript is almost infinite, here are some tools that help you build single-page applications.
