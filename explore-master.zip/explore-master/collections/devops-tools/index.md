---
items:
 - puppetlabs/puppet
 - chef/chef
 - ansible/ansible
 - saltstack/salt
 - hashicorp/vagrant
 - openstack/openstack
 - moby/moby
 - capistrano/capistrano
 - statsd/statsd
 - graphite-project/graphite-web
 - elastic/logstash
 - fabric/fabric
 - grafana/grafana
 - StackStorm/st2
 - openshift/origin
 - getsentry/sentry
 - deployphp/deployer
 - kubernetes/kubernetes
 - netdata/netdata
 - cloud66-oss/habitus
 - Kong/kong
 - jenkinsci/jenkins
 - kubernetes/kubernetes
 - apache/mesos
 - SeleniumHQ/selenium
 - opendiffy/diffy
 
display_name: DevOps tools
---
These tools help you manage servers and deploy happier and more often with more confidence.
