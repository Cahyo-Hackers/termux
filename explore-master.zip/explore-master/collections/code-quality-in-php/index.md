---
items:
 - squizlabs/PHP_CodeSniffer
 - FriendsOfPHP/PHP-CS-Fixer
 - psecio/parse
 - phan/phan
 - sebastianbergmann/phpcpd
 - sebastianbergmann/phploc
 - povils/phpmnd
 - phpmd/phpmd
 - vimeo/psalm
 - infection/infection
display_name: Code Quality Checker Tools For PHP Projects
created_by: umutphp
---
A collection of code quality tools for PHP projects that you can use to analyze and fix your code in your local environments or in CI pipelines. The collection will not contain testing tools.
