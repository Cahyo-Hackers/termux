---
items:
 - 30-seconds/30-seconds-of-code
 - railsgirls/railsgirls.github.io
 - railsbridge/docs
 - mobilebridge/iosbridge
 - freeCodeCamp/freeCodeCamp
 - leachim6/hello-world
 - datasciencemasters/go
 - tuvtran/project-based-learning
 - zhiwehu/Python-programming-exercises
 - MunGell/awesome-for-beginners
 - appacademy/welcome-to-open
 - webgems/webgems

display_name: Learn to Code
created_by: alysonla
image: learn-to-code.png
---
Resources to help people learn to code
