---
items:
 - robbyrussell/oh-my-zsh
 - ggreer/the_silver_searcher
 - arc90/git-sweep
 - bhollis/jsonview
 - ShareX/ShareX
 - sindresorhus/quick-look-plugins
 - rtyley/bfg-repo-cleaner
 - mhagger/git-imerge
 - eddiezane/lunchy
display_name: Software productivity tools
created_by: holman
---
Build software faster with fewer headaches, using these tools and tricks
