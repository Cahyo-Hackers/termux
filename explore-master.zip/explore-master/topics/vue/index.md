---
aliases: vuejs, vuejs2, vue2
created_by: Evan You
display_name: Vue.js
github_url: https://github.com/vuejs/vue
logo: vue.png
related: angular, react
released: February 2014
short_description: Vue.js is a JavaScript framework for building interactive web applications.
topic: vue
url: https://vuejs.org/
wikipedia_url: https://en.wikipedia.org/wiki/Vue.js
---
Vue is a JavaScript framework for building websites. The intent of Vue is to make the integration of other JavaScript libraries easy. It is designed to organize and simplify web development.
