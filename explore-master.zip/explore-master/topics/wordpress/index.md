---
aliases: wordpress-development, wordpress-site
created_by: Matt Mullenweg, Mike Little
display_name: WordPress
github_url: https://github.com/WordPress
logo: wordpress.png
released: May 27, 2003
short_description: WordPress is a popular content management system, used for websites
  and blogs.
topic: wordpress
url: https://wordpress.org/
wikipedia_url: https://en.wikipedia.org/wiki/WordPress
---
WordPress is a popular content management system, used for websites and blogs. WordPress is written in PHP and MySQL and is designed to be flexible and user-friendly.
