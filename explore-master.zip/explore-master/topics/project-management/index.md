---
display_name: Project management
short_description: Project management is about building scope and executing on the project's goals.
topic: project-management
wikipedia_url: https://en.wikipedia.org/wiki/Project_management

---
Project management is the practice of initiating, planning, executing, controlling, and closing the work of a team to achieve specific goals and meet specific success criteria at the specified time.
