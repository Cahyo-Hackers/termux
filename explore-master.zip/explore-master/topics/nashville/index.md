---
created_by: "James Robertson, John Donelson, and a party of Overmountain Men"
display_name: "Nashville, Tennessee"
github_url: https://github.com/code-for-nashville
logo: nashville.png
related: tennessee, nashvillesoftwareschool, east-nashville, open-data, civic-tech
released: 1779
short_description: Nashville is the capital and most populous city of the U.S. state of Tennessee.
topic: nashville
url: https://www.visitmusiccity.com/
wikipedia_url: https://en.wikipedia.org/wiki/Nashville,_Tennessee
---
Nashville is the capital and most populous city of the U.S. state of Tennessee, called the "home of country music." It is a center for the music, healthcare, publishing, private prison, banking, and transportation industries, and is home to numerous colleges and universities. In March 2012, a Gallup poll ranked Nashville in the top five regions for job growth. Nashville lies on the Cumberland River.
