---
topic: wordplate
created_by: Vincent Klaiber
display_name: WordPlate
github_url: https://github.com/wordplate
logo: wordplate.png
released: October 4, 2013
related: wordpress, composer, laravel, symfony, php
short_description: WordPlate is a modern WordPress stack which simplifies WordPress development.
url: https://wordplate.github.io/
---
WordPlate is a modern WordPress stack with a focus on simplicity. You can use it to easily develop WordPress websites with WordPlate. It simplifies the WordPress development.
