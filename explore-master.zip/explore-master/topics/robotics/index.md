---
display_name: Robotics
short_description: Robotics deals with the control, sensory feedback, and information processing of robots.
topic: robotics
wikipedia_url: https://en.wikipedia.org/wiki/Robotics
---
Robotics is a branch of engineering and computer science which works to design, build, program. and operate robots. Robots are used in many environments in which human involvement could be dangerous, including bomb defusal, space repairs, and manufacturing processes. Robots typically work either autonomously or with commands sent by human operators.
