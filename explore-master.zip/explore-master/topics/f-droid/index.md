---
topic: f-droid
aliases: fdroid
display_name: F-Droid
logo: f-droid.png
short_description: F-Droid is an installable catalogue of FOSS applications for the Android platform.
url: https://f-droid.org/
wikipedia_url: https://en.wikipedia.org/wiki/F-Droid
---
F-Droid is an installable catalogue of FOSS (Free and open source software) applications for the Android platform.
