---
aliases: mahapps-metro
created_by: Paul Jenkins
display_name: MahApps.Metro
github_url: https://github.com/MahApps/MahApps.Metro
logo: mahapps.png
related: metro, wpf
released: January 29, 2011
short_description: A toolkit for creating metro-modern-style WPF applications.
topic: mahapps
url: http://mahapps.com/
---
MahApps.Metro is a framework that allows developers to cobble together a `Metro` or `Modern` UI for their own `WPF` applications with minimal effort.
