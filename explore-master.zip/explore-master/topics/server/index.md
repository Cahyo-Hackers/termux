---
aliases: servers
display_name: Server
short_description: A server is a program made to process requests and deliver data
  to clients.
topic: server
wikipedia_url: https://en.wikipedia.org/wiki/Server_(computing)
---
A server is a program or device that provides functionality for other programs and devices, called clients. This relation forms the Client-Server Model.
