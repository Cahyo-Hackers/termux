---
created_by: Takahiro Kamitani, Takanori Katagiri
display_name: Pixiv
logo: pixiv.png
released: September 10, 2007
related: pixiv-downloader, pixiv-api
short_description: Pixiv is an online art community.
topic: pixiv
github_url: https://github.com/pixiv
url: https://www.pixiv.net/
wikipedia_url: https://en.wikipedia.org/wiki/Pixiv
---
Pixiv is an online art community as a place for artist exhibit their illustrations, animations, and writings and get feedback via a rating system and user comments.