---
aliases: aureliajs, aurelia-vnext, vnext, aurelia-spa, spa, jsx, aureliavnext, aurelia-2, aurelia-2-vnext
created_by: Rob Eisenberg
display_name: aurelia
github_url: https://github.com/aurelia/aurelia
logo: aurelia.png
related: angular, react, vue, vuejs, inferno, mithril, ember, durandal, meteor, meteorjs
released: July 2016
short_description: A next generation JavaScript client framework that leverages simple conventions to empower your creativity.
topic: aurelia
url: https://aurelia.io
wikipedia_url: https://en.wikipedia.org/wiki/aurelia.js
---
Aurelia is a next generation JavaScript client framework that leverages simple conventions to empower your creativity.
