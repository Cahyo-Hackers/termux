---
aliases: electronjs
created_by: GitHub
display_name: Electron
github_url: https://github.com/electron/electron
logo: electron.png
related: electron-app, electron-application
released: July 15, 2013
short_description: Electron is a framework for building cross-platform desktop applications
  with web technology.
topic: electron
url: http://electronjs.org/
wikipedia_url: https://en.wikipedia.org/wiki/Electron_(software_framework)
---
Electron is a desktop application framework developed by GitHub and created by Cheng Zhao. It allows for the development of desktop applications using front- and back-end infrastructure such as HTML, CSS, and JavaScript.
