---
aliases: gulpjs, gulp-js
created_by: Fractal Innovations and the open source community at GitHub
display_name: Gulp
github_url: https://github.com/gulpjs
logo: gulp.png
released: February 9, 2016
short_description: Gulp is a toolkit for automating and streamlining web development.
topic: gulp
url: http://gulpjs.com/
wikipedia_url: https://en.wikipedia.org/wiki/Gulp.js
---
Gulp is an open source toolkit built on Node.js and npm. It is used for automating and streamlining repetitive tasks in front-end web development.
