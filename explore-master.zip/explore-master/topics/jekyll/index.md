---
aliases: jekyll-theme, jekyll-site, jekyll-themes, jekyll-website
created_by: Tom Preston-Werner
display_name: Jekyll
github_url: https://github.com/jekyll
logo: jekyll.png
released: '2008'
short_description: Jekyll is a simple, blog-aware static site generator.
topic: jekyll
url: http://jekyllrb.com/
wikipedia_url: https://en.wikipedia.org/wiki/Jekyll_(software)
---
Jekyll is a blog-aware, site generator written in Ruby. It takes raw text files, runs it through a renderer and produces a publishable static website.
