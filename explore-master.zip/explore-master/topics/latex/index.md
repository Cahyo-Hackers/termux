---
aliases: latex-template, latex-class, latex-package, latex-document, latex-examples
created_by: Leslie Lamport
display_name: LaTeX
github_url: https://github.com/latex3
logo: latex.png
related: tex
released: 1985
short_description: LaTeX is a document preparation system.
topic: latex
url: https://www.latex-project.org/
wikipedia_url: https://en.wikipedia.org/wiki/LaTeX
---
LaTeX is a typesetting system used to create technical and scientific documents. It is an alternative to word processing, with an emphasis on content over appearance.
