---
aliases: openfin-api
display_name: OpenFin
short_description: OpenFin allows web applications to run as first-class citizens on the desktop.
topic: openfin
created_by: Brian Schwinn
github_url: https://github.com/openfin
logo: openfin.png
released: December 2012
url: https://openfin.co
---
OpenFin is a web application runtime and API that brings native user experience and interoperability to web applications.  Built on Chromium, OpenFin brings the latest in web standards to the Financial community.
