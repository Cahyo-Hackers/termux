---
aliases: zeplin-extension,zem
created_by: Zeplin
display_name: Zeplin
github_url: https://github.com/zeplin
logo: zeplin.png
released: June 2014
short_description: Zeplin is a connected space for product teams where they can share designs, generate specs, assets and code snippets.
topic: zeplin
url: https://zeplin.io
---
Zeplin is a connected space for product teams. It helps you collect and organize your team’s projects and resources like components, colors, and text styles. Everyone in the team can access up to date design resources and discussions. They also get notified of changes easily.