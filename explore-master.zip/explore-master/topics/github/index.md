---
created_by: Chris Wanstrath, PJ Hyett, Tom Preston-Werner, and Scott Chacon
display_name: GitHub
github_url: https://github.com/github
logo: github.png
released: April 10, 2008
short_description: You’re lookin’ at it.
topic: github
related: git
url: https://github.com
wikipedia_url: https://en.wikipedia.org/wiki/GitHub
---
GitHub makes it easier for developers to be developers: to work together, to solve challenging problems, to create the world’s most important technologies.
