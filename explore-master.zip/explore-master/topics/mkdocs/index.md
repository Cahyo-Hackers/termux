---
created_by: Tom Christie
display_name: MkDocs
github_url: https://github.com/mkdocs/mkdocs/
released: '2014'
short_description: MkDocs is a static site generator that's focused on project documentation.
topic: mkdocs
url: https://www.mkdocs.org/
---
MkDocs is a fast, simple and downright gorgeous static site generator that's geared towards building project documentation. Documentation source files are written in Markdown, and configured with a single YAML configuration file.
