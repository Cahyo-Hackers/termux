---
aliases: frc, first-frc
created_by: FIRST
display_name: FIRST Robotics Competition
github_url: https://github.com/first
logo: first-robotics-competition.png
short_description: FIRST Robotics Competition is a robotics competition for 9-12th graders where teams compete head-to-head in annual challenges.
topic: first-robotics-competition
url: https://www.firstinspires.org/robotics/frc
wikipedia_url: https://en.wikipedia.org/wiki/FIRST_Robotics_Competition
---

FIRST Robotics Competition (FRC) is a robotics competition for students in grades 9-12 to compete head to head, using a sports model. Teams are responsible for designing, building, and programming their robots in a six-week build period to compete in an alliance format against other teams.
