---
aliases: nettefw, nette-framework
created_by: David Grudl
display_name: Nette
github_url: https://github.com/nette/nette
logo: nette.png
related: framework, mvc, php
released: '2008'
short_description: Nette – Comfortable and Safe Web Development in PHP.
topic: nette
url: https://nette.org/
---
Nette Framework is a popular tool for PHP web development. It is designed to be as usable and as friendly as possible. It focuses on security and performance and is definitely one of the safest PHP frameworks.
