---
aliases: django-framework, django-application
created_by: Adrian Holovaty, Simon Willison
display_name: Django
github_url: https://github.com/django/django
logo: django.png
released: 21 July 2005
short_description: Django is a web application framework for Python.
topic: django
url: https://www.djangoproject.com/
wikipedia_url: https://en.wikipedia.org/wiki/Django_(web_framework)
---
Django is a web application framework for Python. It is designed to prioritize principles of reusability and rapid development.
