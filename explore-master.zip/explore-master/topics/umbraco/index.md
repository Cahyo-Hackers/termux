---
aliases: umbraco-cms, umbraco-backoffice, umbraco-v7, umbraco-v8
created_by: Niels Hartvig
display_name: Umbraco
github_url: https://github.com/umbraco/
logo: umbraco.png
related: umbraco-cloud, umbraco-community, umbraco-forms, umbraco-headless, umbraco-packages
released: February 16, 2005
short_description: Umbraco is the leading open source ASP.NET CMS.
topic: umbraco
url: https://umbraco.com/
wikipedia_url: https://en.wikipedia.org/wiki/Umbraco
---
Umbraco is the friendliest, most flexible and fastest growing ASP.NET CMS, and used by more than 500,000 websites worldwide.
