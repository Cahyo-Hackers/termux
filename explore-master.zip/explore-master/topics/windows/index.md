---
aliases: windows-10, windows10, windows-7, windows-8
created_by: Microsoft Corporation
display_name: Windows
github_url: https://github.com/Microsoft
logo: windows.png
released: November 20, 1985
short_description: Windows is Microsoft's GUI-based operating system.
topic: windows
url: https://www.microsoft.com/en-us/windows
wikipedia_url: https://en.wikipedia.org/wiki/Microsoft_Windows
---
Windows is Microsoft's GUI-based operating system. It is known for its graphical display and is designed to be user-friendly.
