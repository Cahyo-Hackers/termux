---
aliases: icon-fonts
display_name: Icon font
short_description: Icon fonts contain glyphs and symbols in place of textual letters.
topic: icon-font
---
Icon fonts are vector graphics that contain glyphs and symbols instead of letters and numbers. They may be styled with CSS, similar to regular text.
