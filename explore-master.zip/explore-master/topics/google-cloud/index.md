---
aliases: google-cloud-platform, gcp, googlecloudplatform
display_name: Google Cloud Platform
topic: google-cloud
github_url: https://github.com/GoogleCloudPlatform
related: google, firebase
released: April 7, 2008
short_description: Google Cloud Platform, offered by Google, is a suite of cloud computing services.
url: https://cloud.google.com
wikipedia_url: https://en.wikipedia.org/wiki/Google_Cloud_Platform
---
Google Cloud Platform, offered by Google, is a suite of cloud computing services. Google Cloud Platform provides Infrastructure as a Service, Platform as a Service, and Serverless Computing environments.
