---
aliases: springboot
created_by: Pivotal Software
display_name: Spring Boot
github_url: https://github.com/spring-projects/spring-framework
logo: spring-boot.png
released: October 1, 2002
short_description: Spring Boot is a coding and configuration model for Java applications.
topic: spring-boot
url: https://spring.io/
wikipedia_url: https://en.wikipedia.org/wiki/Spring_Framework
---
Spring Boot is a coding and configuration model for Java applications. Spring was developed by Pivotal Software.
