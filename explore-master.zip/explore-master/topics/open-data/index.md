---
aliases: opendata
display_name: Open Data
related: data, dataset, linked-open-data, open-access, open-science, openstreetmap, wikidata
short_description: Open data can be freely used, re-used and redistributed by anyone.
topic: open-data
wikipedia_url: https://en.wikipedia.org/wiki/Open_data
---
Open data is data that can be freely used, re-used, and redistributed by anyone - subject only, at most, to the requirement to attribute and sharealike.
