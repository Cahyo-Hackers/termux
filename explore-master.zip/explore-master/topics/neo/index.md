---
created_by: Hongfei Da, Erik Zhang
display_name: NEO
logo: neo.png
released: July 15, 2016
short_description: A distributed network for the Smart Economy.
topic: neo
related: blockchain, cryptocurrency
url: https://www.neo.org/
github_url: https://github.com/neo-project
wikipedia_url: https://en.wikipedia.org/wiki/NEO_(cryptocurrency)
---
NEO is the use of blockchain technology and digital identity to digitize assets, the use of smart contracts for digital assets to be self-managed, to achieve "smart economy" with a distributed network.