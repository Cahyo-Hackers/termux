---
aliases: visualbasic, vb, vbnet, vb-net
created_by: Microsoft
display_name: Visual Basic
github_url: https://github.com/dotnet/vblang
logo: visual-basic.png
related: language, dotnet
released: May 1991
short_description: Visual Basic is an object-oriented and type-safe programming language.
topic: visual-basic
url: https://docs.microsoft.com/dotnet/visual-basic/
wikipedia_url: https://en.wikipedia.org/wiki/Visual_Basic_.NET
---
Visual Basic is an approachable language with a simple syntax for building type-safe, object-oriented apps.
