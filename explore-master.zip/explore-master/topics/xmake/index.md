---
created_by: ruki
display_name: xmake
github_url: https://github.com/tboox/xmake
logo: xmake.png
released: June 8, 2015
short_description: xmake is a cross-platform build utility based on lua.
topic: xmake
url: https://xmake.io/
---
xmake is a cross-platform build utility based on lua. It focuses on making development and building easier and provides many features, so that any developer can quickly pick it up and enjoy the productivity boost when developing and building project.
