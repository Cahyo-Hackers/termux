---
aliases: tns
created_by: Progress
display_name: NativeScript
github_url: https://github.com/nativescript
logo: nativescript.png
released: March 2015
short_description: NativeScript is a JavaScript-native mobile framework.
topic: nativescript
url: https://www.nativescript.org/
wikipedia_url: https://en.wikipedia.org/wiki/NativeScript
---
NativeScript is a JavaScript-native mobile framework developed by Progress. NativeScript allows developers to build truly native cross-platform iOS/Android mobile apps using existing web skills (JavaScript, CSS, XML) and established frameworks (Angular and Vue).