---
topic: lineageos
github_url: https://github.com/LineageOS
display_name: LineageOS
short_description: A free and open source operating system for smartphones and tablet computers.
url: https://www.lineageos.org/
wikipedia_url: https://en.wikipedia.org/wiki/LineageOS
---

LineageOS is a free and open source operating system for smartphones and tablet computers, based on the Android mobile platform.
