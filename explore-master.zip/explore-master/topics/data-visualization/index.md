---
aliases: dataviz
created_by: Charles Joseph Minard
display_name: Data visualization
short_description: Data visualization is the graphic representation of data and trends.
topic: data-visualization
wikipedia_url: https://en.wikipedia.org/wiki/Data_visualization
---
Data visualization is the visual depiction of data through the use of graphs, plots, and informational graphics. Its practitioners use statistics and data science to convey the meaning behind data in ethical and accurate ways.
