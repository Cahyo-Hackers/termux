---
created_by: John Resig
display_name: jQuery
github_url: https://github.com/jquery/jquery
logo: jquery.png
released: January 2006
short_description: jQuery is a lightweight library that simplifies programming with
  JavaScript.
topic: jquery
url: https://jquery.com/
wikipedia_url: https://en.wikipedia.org/wiki/JQuery
---
jQuery is a lightweight library that simplifies programming with JavaScript. It builds on top of browser function and accomplishes programming tasks with fewer lines of code.
