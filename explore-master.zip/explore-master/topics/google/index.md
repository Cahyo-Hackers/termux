---
display_name: Google
github_url: https://github.com/google
logo: google.png
created_by: Larry Page, Sergey Brin
released: September 4, 1998
short_description: Google LLC is an American multinational technology company that specializes in Internet-related services and products.
topic: google
url: https://www.google.com
wikipedia_url: https://en.wikipedia.org/wiki/Google
---
Google is an American multinational technology company that specializes in Internet-related services and products, which include online advertising technologies, search engine, cloud computing, software, and hardware.