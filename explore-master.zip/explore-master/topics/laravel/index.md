---
aliases: laravel4, laravel5, laravel54, laravel55, laravel-framework, laravel6
created_by: Taylor Otwell
display_name: Laravel
github_url: https://github.com/laravel
logo: laravel.png
related: framework, php
released: June 2011
short_description: The PHP Framework for Web Artisans.
topic: laravel
url: https://laravel.com/
wikipedia_url: https://en.wikipedia.org/wiki/Laravel
---
Laravel is a popular PHP framework, used for the development of MVC web applications.
