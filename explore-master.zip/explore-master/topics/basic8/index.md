---
display_name: BASIC8
aliases: basic-8
related: tic-80, pico-8, liko-12, pixel-vision-8
short_description: BASIC8 is an integrated Fantasy Computer for game, and other program development.
topic: basic8
url: https://paladin-t.github.io/b8/
github_url: https://github.com/paladin-t/b8
created_by: Wang Renxin
logo: basic8.png
---
BASIC8 is an integrated Fantasy Computer for game, and other program development. You can create, share, and play disks in a modern BASIC dialect, with built-in tools for editing sprites, tiles, maps, and more.
