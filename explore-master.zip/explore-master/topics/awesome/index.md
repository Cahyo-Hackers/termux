---
display_name: Awesome Lists
topic: awesome
aliases: awesome-lists, awesome-list
created_by: Sindre Sorhus and the community
github_url: https://github.com/sindresorhus/awesome
logo: awesome.png
released: July 11, 2014
short_description: An awesome list is a list of awesome things curated by the community.
url: https://awesome.re/
---
An awesome list is a list of awesome things curated by the community. There are awesome lists about everything from [CLI applications](https://github.com/agarrharr/awesome-cli-apps) to [fantasy books](https://github.com/RichardLitt/awesome-fantasy). The [main repository](https://github.com/sindresorhus/awesome) serves as a curated list of awesome lists.
