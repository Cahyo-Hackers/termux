---
aliases: ios-app, ios-swift, ios10, ios11
created_by: Apple Inc.
display_name: iOS
logo: ios.png
released: June 29, 2007
short_description: iOS is the operating system for Apple's mobile products.
topic: ios
url: https://www.apple.com/ios/
wikipedia_url: https://en.wikipedia.org/wiki/IOS
---
iOS is the operating system for all of Apple’s mobile products. The operating system was unveiled at Macworld Conference and Expo in 2007 to support the company’s new venture, the iPhone. Since then, the operating system has grown to incorporate other products, including the iPad and iPod Touch.
