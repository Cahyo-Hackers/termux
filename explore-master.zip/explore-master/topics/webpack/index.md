---
aliases: webpack2, webpack3
created_by: Tobias Koppers, Sean Larkin, Johannes Ewald, Juho Vepsäläinen, Kees Kluskens
display_name: Webpack
github_url: https://github.com/webpack
logo: webpack.png
released: March 10, 2012
short_description: Webpack is a bundler that takes modules with dependencies and creates
  static assets.
topic: webpack
url: https://webpack.js.org/
wikipedia_url: https://en.wikipedia.org/wiki/Webpack
---
Webpack is a bundler that takes modules with dependencies and creates static assets. It is designed to simplify and enhance the development and user experience.
