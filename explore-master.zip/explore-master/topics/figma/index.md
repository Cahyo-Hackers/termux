---
created_by: Figma
display_name: Figma
github_url: https://github.com/figma
logo: figma.png
released: 2012
short_description: Figma is a collaborative interface design tool.
topic: figma
url: https://www.figma.com/
---
Figma is a collaborative interface design tool that enables the entire team’s design process to happen in one online tool.