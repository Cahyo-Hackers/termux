---
created_by: Brandon Keepers, Bex Warner
related: probot-app, github-apps, bot, node-github
display_name: Probot
github_url: https://github.com/probot/
logo: probot.png
released: March 2017
short_description: Probot lets you create GitHub Apps to automate and improve your workflow.
topic: probot
url: https://probot.github.io/
---
Probot is a framework for building GitHub Apps in Node.js. Use pre-built apps to extend GitHub, and easily build and share your own.
