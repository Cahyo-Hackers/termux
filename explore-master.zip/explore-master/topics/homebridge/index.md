---
created_by: Khaos Tian, Nick Farina
display_name: Homebridge
github_url: https://github.com/nfarina/homebridge
released: February 16, 2016
short_description: Homebridge is a utility for tying smart home devices together into
  Apple’s HomeKit framework, controlled by Siri.
topic: homebridge
---
Homebridge is a lightweight Node.js server that emulates the iOS HomeKit API. Using HomeBridge, Siri can control devices that are not supported through HomeKit.
