---
created_by: Roberto Ierusalimschy, Waldemar Celes, and Luiz Henrique de Figueiredo
display_name: Lua
github_url: https://github.com/lua
logo: lua.png
related: language
released: 1993
short_description: Lua is a lightweight, embeddable scripting language.
topic: lua
url: https://www.lua.org/
wikipedia_url: https://en.wikipedia.org/wiki/Lua_(programming_language)
---
Lua is a programming language written in C that emphasizes performance. It has automatic memory management and is often used to extend software written in other languages.
