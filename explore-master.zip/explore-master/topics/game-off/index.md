---
aliases: github-game-off, githubgameoff, gameoff, ggo12, ggo13, ggo14, ggo15, ggo16
related: global-game-jam, ludum-dare, js13kgames
display_name: Game Off
short_description: Game Off is an annual game jam celebrating open source.
topic: game-off
logo: game-off.png
url: https://gameoff.github.com/
---
Game Off is a month-long game jam celebrating open source. Each November, game developers are challenged to create a game based on a theme and share it (and the source) with the world.
