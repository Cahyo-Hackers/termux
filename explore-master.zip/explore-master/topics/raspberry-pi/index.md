---
aliases: raspberry-pi-4, raspberry-pi-3, raspberry-pi-2, raspberry-pi-camera, raspberrypi
created_by: Raspberry Pi Foundation
display_name: Raspberry Pi
github_url: https://github.com/raspberrypi
logo: raspberry-pi.png
released: July 2011
short_description: The Raspberry Pi is a popular single-board computer.
topic: raspberry-pi
url: https://www.raspberrypi.org
wikipedia_url: https://en.wikipedia.org/wiki/Raspberry_Pi
---
The Raspberry Pi is a popular single-board computer designed to promote the teaching of computer science in schools. The use of the Raspberry Pi computer ranges from robotics to home automation. Many variations of the Raspberry Pi exist, such as the Raspberry Pi Zero, which is smaller than the more powerful Raspberry Pi 4.
