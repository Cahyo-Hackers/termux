---
created_by: Xavier Leroy
display_name: OCaml
github_url: https://github.com/ocaml/ocaml
logo: ocaml.png
released: 1996
short_description: OCaml is an implementation of the ML language, based on the Caml Light.
topic: ocaml
url: http://ocaml.org
wikipedia_url: https://en.wikipedia.org/wiki/OCaml
---
OCaml is a general purpose industrial-strength programming language with an emphasis on expressiveness and safety, It is supporting functional, imperative and object-oriented styles.
