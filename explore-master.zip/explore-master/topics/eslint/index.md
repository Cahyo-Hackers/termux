---
created_by: Nicholas C. Zakas
display_name: ESLint
github_url: https://github.com/eslint/eslint
logo: eslint.png
aliases: eslint-plugin, eslint-config
related: linting, linter, javascript
released: June 2013
short_description: The pluggable linting utility for JavaScript and JSX.
topic: eslint
url: https://eslint.org/
---
ESLint is an extensible static-analysis tool for JavaScript and related languages that helps catch errors before they break something in production.
